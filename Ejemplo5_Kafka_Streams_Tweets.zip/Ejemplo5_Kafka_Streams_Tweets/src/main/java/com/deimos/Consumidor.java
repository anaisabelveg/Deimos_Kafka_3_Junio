package com.deimos;

import java.util.Collections;
import java.util.Properties;

import org.apache.kafka.common.serialization.Serdes;
import org.apache.kafka.streams.KafkaStreams;
import org.apache.kafka.streams.StreamsBuilder;
import org.apache.kafka.streams.StreamsConfig;
import org.apache.kafka.streams.Topology;
import org.apache.kafka.streams.kstream.KStream;
import org.apache.kafka.streams.kstream.Printed;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

public class Consumidor {
	
	public static ObjectMapper objectMapper = new ObjectMapper();

	public static void main(String[] args) {

		Properties props = new Properties();
		
		// Necesitamos un identificador de aplicacion
		props.put(StreamsConfig.APPLICATION_ID_CONFIG, "ejemplo_deimos_tweets");

		// Especificar los host y puertos de todos los brokers del cluster
		// Asegurar que tenemos los 3 brokers levantados
		props.put(StreamsConfig.BOOTSTRAP_SERVERS_CONFIG, "localhost:9092,localhost:9093,localhost:9094");

		// Elegir como deserializar la clave y el valor del mensaje
		props.put(StreamsConfig.DEFAULT_KEY_SERDE_CLASS_CONFIG, Serdes.String().getClass().getName());
		props.put(StreamsConfig.DEFAULT_VALUE_SERDE_CLASS_CONFIG, Serdes.String().getClass().getName());

		// Asignar el consumidor a un grupo
		props.put("group.id", "grupo1");

		// Timeout por defecto de 3 segundos
		props.put("session.timeout.ms", 10_000); // milisegundos

		// La cantidad minimo de bytes que quiere recibir del broker
		props.put("fetch.min.bytes", "1");

		// Cuanto tiempo como maximo esta dispuesto a esperar para recibir esa cantidad
		// de bytes
		props.put("fetch.max.wait.ms", "1000"); // milisegundos
		
		// Crear un KStream a partir del topic deimos-tweets
		StreamsBuilder builder = new StreamsBuilder();
		KStream<String, String> flujoTweets = builder.stream("deimos-tweets");
		
		// Procesar mensajes
		flujoTweets
			.flatMapValues(value -> Collections.singletonList(getHashtags(value)))
			.groupBy((key, value) -> value )
			.count()
			.toStream()
			.print(Printed.toSysOut());
		
		Topology topology = builder.build();
		KafkaStreams kStreams = new KafkaStreams(topology, props);
		kStreams.start();

	}
	
	
	public static String getHashtags(String mensaje) {
		
		String tag = "";
		
		JsonNode root;
		
		try {
			root = objectMapper.readTree(mensaje);
			// recuperar el hashtag
			JsonNode hashtagsNode = root.path("entities").path("hashtags");
			
			if (! hashtagsNode.toString().equals("[]")) {
				 // Nos quedamos solo con el primero
				tag = hashtagsNode.get(0).path("tag").asText();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return tag;
	}
	

}















