package com.deimos;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.Properties;

import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.clients.producer.ProducerRecord;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

public class Productor {
	
	public static ObjectMapper objectMapper = new ObjectMapper();

	public static void main (String[] args) {
		Properties props = new Properties();
		
		//especificar ports y puertos de todos los brokers del cluster
		//asegurar que tenemos los 3 brokers levantados
		props.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, "localhost:9092,localhost:9093,localhost:9094");
		
		//elegir como serializar la clave y valor del mensaje
		props.put("key.serializer", "org.apache.kafka.common.serialization.StringSerializer");
		props.put("value.serializer", "org.apache.kafka.common.serialization.StringSerializer");
		
		//num intentos en caso de fallo
		props.put("retries", 0);
		
		//ACKs --> confirmacion de envio de mensaje?
		//0 --> el productor no recibe ACK
		//1 --> el productor espera ACK por parte del broker que lo ha recibido (no tengo certeza de que lo hayan recibido todas)
		//all --> el productor recibe la confirmacion cuando todas las replicas sincronizadas del cluster, lo han recibido
		//        es la opcion mas segura, pero mayor impacto en la latencia / rapidez
		props.put("acks", "all");
		
		//tamaño del buffer (en bytes)
		//acumula los mensajes/eventos que pertenecen a la misma particion para enviarlos
		props.put("batch.size",  20_000);
		
		//controlar el total de la memoria disponible para el productor
		props.put("buffer.memory", 400_000);
		
		KafkaProducer<String, String> producer = new KafkaProducer<String, String>(props);
		
		try (BufferedReader br = new BufferedReader(new FileReader("tweets.txt"))) {
			String linea;
			while ((linea = br.readLine()) != null) {
				//System.out.println("linea leida: " + linea);
				JsonNode root;
				try {
					// la linea leida, la convertimos en un nodo JSON
					root = objectMapper.readTree(linea);
					
					// recuperar el hashtag
					JsonNode hashtagsNode = root.path("entities").path("hashtags");
					
					// procesamos solo los hashtags con contenido
					if (! "".equals(hashtagsNode.toString())) {
						// el idioma sera la key
						String key = root.path("lang").toString();
						// la linea entera leida como JSON es el value
						String value = root.toString();
						// productor envia el mensaje/evento al topic
						producer.send(new ProducerRecord<String, String>("deimos-tweets", key, value));
					}
				} catch (Exception e1) {
					e1.printStackTrace();
				}
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}

