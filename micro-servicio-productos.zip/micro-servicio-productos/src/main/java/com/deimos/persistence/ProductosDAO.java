package com.deimos.persistence;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

import com.deimos.models.Producto;

@RepositoryRestResource(collectionResourceRel = "PRODUCTOS", path = "productos")
public interface ProductosDAO extends JpaRepository<Producto, Integer>{

	// http://localhost:8001/productos
}
