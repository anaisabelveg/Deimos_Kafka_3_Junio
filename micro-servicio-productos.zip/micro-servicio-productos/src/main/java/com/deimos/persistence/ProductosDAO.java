package com.deimos.persistence;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

import com.deimos.models.Producto;

@RepositoryRestResource(collectionResourceRel = "PRODUCTOS", path = "productos")
public interface ProductosDAO extends JpaRepository<Producto, Integer> {

	// Consultar todos los productos
	// http://localhost:8001/productos

	// Buscar el producto con id=3
	// http://localhost:8001/productos/3

	// Podemos crear nuestros propios metodos utilizando paralabras clave
	// https://docs.spring.io/spring-data/jpa/docs/current/reference/html/#repository-query-keywords
	
	// http://localhost:8001/productos/search/findByDescripcion?descripcion=Raton
	public List<Producto> findByDescripcion(String descripcion);

	// Ver todos los metodos personalizados
	// http://localhost:8001/productos/search

	// http://localhost:8001/productos/search/OrderByPrecio
	public List<Producto> OrderByPrecio();

	// http://localhost:8001/productos/search/findByPrecioBetween?min=80&max=200
	public List<Producto> findByPrecioBetween(double min, double max);
}
