package com.deimos.services;

import java.util.List;

import com.deimos.models.Producto;

public interface IProductoService {
	
	List<Producto> consultarTodos();
	
	Producto buscarProducto(Integer id);
	
	void crearProducto(Producto producto);

}
