package com.deimos.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.deimos.kafka.Productor;
import com.deimos.models.Producto;
import com.deimos.persistence.ProductosDAO;

@Service
public class ProductoServiceImpl implements IProductoService{
	
	@Autowired
	private ProductosDAO dao;
	
	@Autowired
	private Productor productor;

	@Override
	public List<Producto> consultarTodos() {
		return dao.findAll();
	}

	@Override
	public Producto buscarProducto(Integer id) {
		return dao.findById(id).orElse(new Producto());
	}

	@Override
	public void crearProducto(Producto producto) {
		// Spring kafka
		System.out.println("producto enviado: " + producto);
		productor.enviarMensaje(producto);
	}

}
