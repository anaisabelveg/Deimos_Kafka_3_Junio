package com.deimos.kafka;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

import com.deimos.models.Producto;
import com.deimos.persistence.ProductosDAO;

@Service
public class Consumidor {
	
	@Autowired
	private ProductosDAO dao;
	
//	@KafkaListener(topics = "deimos-cluster", groupId = "grupo1")
//	public void recibirMensaje(Producto producto) {
//		System.out.println("Mensaje recibido: " + producto);
//		dao.save(producto);
//	}
}
