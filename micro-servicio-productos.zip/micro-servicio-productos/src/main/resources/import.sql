insert into PRODUCTOS (DESCRIPCION, PRECIO) values ('Pantalla', 129.50);
insert into PRODUCTOS (DESCRIPCION, PRECIO) values ('Teclado', 50.85);
insert into PRODUCTOS (DESCRIPCION, PRECIO) values ('Raton', 18.75);
insert into PRODUCTOS (DESCRIPCION, PRECIO) values ('Impresora', 99.80);