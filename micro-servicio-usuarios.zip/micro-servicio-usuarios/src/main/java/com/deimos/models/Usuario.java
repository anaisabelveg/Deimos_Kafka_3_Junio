package com.deimos.models;

import java.io.Serializable;

import org.springframework.data.annotation.Id;

public class Usuario implements Serializable {

	@Id
	private String id;

	private String user;
	private String pw;

	public Usuario() {
		// TODO Auto-generated constructor stub
	}

	public Usuario(String user, String pw) {
		super();
		this.user = user;
		this.pw = pw;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getUser() {
		return user;
	}

	public void setUser(String user) {
		this.user = user;
	}

	public String getPw() {
		return pw;
	}

	public void setPw(String pw) {
		this.pw = pw;
	}

	@Override
	public String toString() {
		return "Usuario [id=" + id + ", user=" + user + ", pw=" + pw + "]";
	}

	

}
