package com.deimos.services;

import com.deimos.models.Usuario;

public interface IUsuariosService {
	
	Usuario buscar(String user);
	
	Usuario crear(Usuario usuario);

}
