package com.deimos.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.deimos.kafka.Productor;
import com.deimos.models.Usuario;
import com.deimos.persistence.UsuariosDAO;

@Service
public class UsuariosServiceImpl implements IUsuariosService{
	
	@Autowired
	private UsuariosDAO dao;
	
	@Autowired
	private Productor productor;

	@Override
	public Usuario buscar(String user) {
		return dao.findByUser(user);
	}

	@Override
	public Usuario crear(Usuario usuario) {
		// Comprobar si no existe ese usuario
		productor.enviarMensaje(usuario);
		System.out.println("Mensaje enviado: " + usuario);
		return usuario;
	}

}
