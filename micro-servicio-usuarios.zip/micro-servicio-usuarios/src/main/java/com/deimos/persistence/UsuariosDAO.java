package com.deimos.persistence;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

import com.deimos.models.Usuario;

@RepositoryRestResource(collectionResourceRel = "USUARIOS", path = "usuarios")
public interface UsuariosDAO extends MongoRepository<Usuario, String>{
	
	// URL para ver todos los usuarios
	// http://localhost:8004/usuarios
	
	// http://localhost:8004/usuarios/search/findByUser?user=Pepito
	public Usuario findByUser(String user);

}
