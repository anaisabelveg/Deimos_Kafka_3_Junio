package com.deimos.kafka;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

import com.deimos.models.Usuario;
import com.deimos.persistence.UsuariosDAO;

@Service
public class Consumidor {
	
	@Autowired
	private UsuariosDAO dao;
	
//	@KafkaListener(topics = "deimos-cluster", groupId = "grupo1")
//	public void recibirMensaje(Usuario usuario) {
//		System.out.println("Mensaje recibido: " + usuario);
//		dao.save(usuario);
//	}
}
