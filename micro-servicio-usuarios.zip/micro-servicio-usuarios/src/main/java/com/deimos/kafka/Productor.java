package com.deimos.kafka;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

import com.deimos.models.Usuario;

@Service
public class Productor {
	
	@Autowired
	private KafkaTemplate<String, Object> kafkaTemplate;
	
	public void enviarMensaje(Usuario usuario) {
		kafkaTemplate.send("deimos-cluster", usuario); // topic, mensaje
	}
}
