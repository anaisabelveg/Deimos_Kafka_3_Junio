package com.deimos;

import java.time.Duration;
import java.time.temporal.ChronoUnit;
import java.util.Properties;

import org.apache.kafka.common.serialization.Serdes;
import org.apache.kafka.streams.KafkaStreams;
import org.apache.kafka.streams.KeyValue;
import org.apache.kafka.streams.StreamsBuilder;
import org.apache.kafka.streams.StreamsConfig;
import org.apache.kafka.streams.Topology;
import org.apache.kafka.streams.kstream.JoinWindows;
import org.apache.kafka.streams.kstream.Joined;
import org.apache.kafka.streams.kstream.KGroupedStream;
import org.apache.kafka.streams.kstream.KStream;
import org.apache.kafka.streams.kstream.KTable;
import org.apache.kafka.streams.kstream.Printed;
import org.apache.kafka.streams.kstream.StreamJoined;

public class Consumidor {

	public static void main(String[] args) {

		Properties props = new Properties();
		props.put(StreamsConfig.APPLICATION_ID_CONFIG, "ejemplo_deimos_transformaciones");
		props.put(StreamsConfig.BOOTSTRAP_SERVERS_CONFIG, "localhost:9092,localhost:9093,localhost:9094");
		props.put(StreamsConfig.DEFAULT_KEY_SERDE_CLASS_CONFIG, Serdes.String().getClass().getName());
		props.put(StreamsConfig.DEFAULT_VALUE_SERDE_CLASS_CONFIG, Serdes.String().getClass().getName());
		props.put("group.id", "grupo1");
		props.put("session.timeout.ms", 10_000); // milisegundos
		props.put("fetch.min.bytes", "1");
		props.put("fetch.max.wait.ms", "1000"); // milisegundos

		// Crear un KStream a partir del topic deimos-cluster
		StreamsBuilder builder = new StreamsBuilder();
		KStream<String, String> flujoProductos = builder.stream("deimos-productos");
		KStream<String, String> flujoProveedores = builder.stream("deimos-proveedores");

		/*
		 * Transformaciones Stateful
		 */

		// inner join
//		KStream<String, String> flujoInnerJoin = flujoProductos.join(flujoProveedores,
//				(val_producto, val_proveedor) -> val_producto + " " + val_proveedor, // valor del nuevo elemento
//
//				JoinWindows.ofTimeDifferenceWithNoGrace(Duration.of(10, ChronoUnit.SECONDS)),
//				StreamJoined.with(Serdes.String(), // tipo key
//						Serdes.String(), // tipo value de productos
//						Serdes.String() // tipo value de proveedores
//				));
//		flujoInnerJoin.foreach((key, value) -> System.out.println(key + " " + value));
		/* Salida por consola
		 * prod3 Raton provC 
		 * prod2 Teclado provB 
		 * prod1 Pantalla provA
		 */

		// left join
		KStream<String, String> flujoLeftJoin = flujoProductos.leftJoin(flujoProveedores,
				(val_producto, val_proveedor) -> val_producto + " " + val_proveedor, // valor del nuevo elemento
																								
				JoinWindows.ofTimeDifferenceWithNoGrace(Duration.of(10, ChronoUnit.SECONDS)), 
				StreamJoined.with(Serdes.String(), // tipo key
						Serdes.String(), // tipo value de productos
						Serdes.String() // tipo value de proveedores
				));
		flujoLeftJoin.foreach( (key, value) -> System.out.println(key + " " + value) );

		// outer join
//		KStream<String, String> flujoOuterJoin = flujoProductos.outerJoin(flujoProveedores,
//				(val_producto, val_proveedor) -> val_producto + " " + val_proveedor, // valor del nuevo elemento
//																								
//				JoinWindows.ofTimeDifferenceWithNoGrace(Duration.of(10, ChronoUnit.SECONDS)), 
//				StreamJoined.with(Serdes.String(), // tipo key
//						Serdes.String(), // tipo value de productos
//						Serdes.String() // tipo value de proveedores
//				));
//		flujoOuterJoin.foreach( (key, value) -> System.out.println(key + " " + value) );

		Topology topology = builder.build();
		KafkaStreams kStreams = new KafkaStreams(topology, props);
		kStreams.start();

	}

}
