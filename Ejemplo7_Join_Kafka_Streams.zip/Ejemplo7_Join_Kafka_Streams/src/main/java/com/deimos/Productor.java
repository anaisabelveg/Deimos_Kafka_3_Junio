package com.deimos;

import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.clients.producer.ProducerRecord;

public class Productor {

	public static void main(String[] args) {
		Properties props = new Properties();
		props.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, "localhost:9092,localhost:9093,localhost:9094");
		props.put("key.serializer", "org.apache.kafka.common.serialization.StringSerializer");
		props.put("value.serializer", "org.apache.kafka.common.serialization.StringSerializer");
		props.put("retries", 0);
		props.put("acks", "all");
		props.put("batch.size", 20_000);
		props.put("buffer.memory", 400_000);

		KafkaProducer<String, String> producer = new KafkaProducer<String, String>(props);

		Map<String, String> productos = new HashMap<>();
		productos.put("prod1", "Pantalla");
		productos.put("prod2", "Teclado");
		productos.put("prod3", "Raton");
		productos.put("prod4", "Impresora");
		productos.put("prod5", "Disco Duro");
		productos.put("prod6", "Scanner");
		
		productos.forEach((key, value) -> {
			producer.send(new ProducerRecord<String, String>("deimos-productos", key, value));
			System.out.println("Enviado a deimos-productos: " + key + ", " + value);
		});
		
		// Enviamos datos a otro topic para probar el merge en el consumidor
		Map<String, String> proveedores = new HashMap<>();
		proveedores.put("prod1", "provA");
		proveedores.put("prod2", "provB");
		proveedores.put("prod3", "provC");
		proveedores.put("prod7", "provD");
		proveedores.put("prod8", "provE");
		proveedores.put("prod9", "provF");

		proveedores.forEach((key, value) -> {
			producer.send(new ProducerRecord<String, String>("deimos-proveedores", key, value));
			System.out.println("Enviado a deimos-proveedores: " + key + ", " + value);
		});
		
		producer.close();

	}
}
