package com.deimos;

import java.util.Properties;

import org.apache.kafka.common.serialization.Serdes;
import org.apache.kafka.streams.KafkaStreams;
import org.apache.kafka.streams.KeyValue;
import org.apache.kafka.streams.StreamsBuilder;
import org.apache.kafka.streams.StreamsConfig;
import org.apache.kafka.streams.Topology;
import org.apache.kafka.streams.kstream.KGroupedStream;
import org.apache.kafka.streams.kstream.KStream;
import org.apache.kafka.streams.kstream.KTable;
import org.apache.kafka.streams.kstream.Printed;

public class Consumidor {

	public static void main(String[] args) {

		Properties props = new Properties();
		props.put(StreamsConfig.APPLICATION_ID_CONFIG, "ejemplo_deimos_transformaciones");
		props.put(StreamsConfig.BOOTSTRAP_SERVERS_CONFIG, "localhost:9092,localhost:9093,localhost:9094");
		props.put(StreamsConfig.DEFAULT_KEY_SERDE_CLASS_CONFIG, Serdes.String().getClass().getName());
		props.put(StreamsConfig.DEFAULT_VALUE_SERDE_CLASS_CONFIG, Serdes.String().getClass().getName());
		props.put("group.id", "grupo1");
		props.put("session.timeout.ms", 10_000); // milisegundos
		props.put("fetch.min.bytes", "1");
		props.put("fetch.max.wait.ms", "1000"); // milisegundos

		// Crear un KStream a partir del topic deimos-cluster
		StreamsBuilder builder = new StreamsBuilder();
		KStream<String, String> flujo = builder.stream("deimos-cluster");

		/*
		 * Transformaciones Stateless
		 */

		// Foreach
		//flujo.foreach( (key, value) -> System.out.println("El alumno " + key + " con numero " + value) );
		
		// Map
//		flujo.map( (key, value) -> KeyValue.pair(key.toUpperCase(), value.concat("-1")))
//			.foreach( (key, value) -> System.out.println("El alumno " + key + " con numero " + value) );
		
		// Filter
//		flujo.filter( (k,v) -> k.length() > 4 )
//			.foreach( (key, value) -> System.out.println("El alumno " + key + " con numero " + value) );
		
		// Branch
//		KStream<String, String> arrayFlujos[] = flujo.branch(
//				(k,v) -> k.startsWith("A"),
//				(k,v) -> k.startsWith("B"),
//				(k,v) -> true
//		);
//		
//		arrayFlujos[0].foreach( (key, value) -> System.out.println("El alumno " + key + " con numero " + value + " flujo 0") );
//		arrayFlujos[1].foreach( (key, value) -> System.out.println("El alumno " + key + " con numero " + value + " flujo 1") );
//		arrayFlujos[2].foreach( (key, value) -> System.out.println("El alumno " + key + " con numero " + value + " flujo 2") );
		

		// Merge
//		KStream<String, String> flujo1 = builder.stream("deimos-cluster");
//		KStream<String, String> flujo2 = builder.stream("deimos-cluster-2");
//		KStream<String, String> flujoFinal = flujo1.merge(flujo2);
//		flujoFinal.foreach( (key, value) -> System.out.println("El alumno " + key + " con numero " + value) );
		
		// GroupBy
//		KGroupedStream<Object, String> grupoStreams =  flujo
//				.groupBy((k,v) -> k.length());
//		KTable<Object, Long> table =  grupoStreams.count();
//		System.out.println(table);
		
//		KGroupedStream<String, String> grupoStreams =  flujo.groupByKey();
//		KTable<String, Long> table =  grupoStreams.count();
//		table.toStream().foreach((key, value) -> System.out.println("El alumno " + key + " con numero " + value));
		
		// Peek
		flujo
			.peek((k,v) -> System.out.println("Procesando " + k) )
			.filter( (k,v) -> k.length() > 4 )
			.foreach( (key, value) -> System.out.println("El alumno " + key + " con numero " + value) );
		

		Topology topology = builder.build();
		KafkaStreams kStreams = new KafkaStreams(topology, props);
		kStreams.start();

	}

}
