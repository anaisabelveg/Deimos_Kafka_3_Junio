package com.deimos;

import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.clients.producer.ProducerRecord;

public class Productor {

	public static void main(String[] args) {
		Properties props = new Properties();
		props.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, "localhost:9092,localhost:9093,localhost:9094");
		props.put("key.serializer", "org.apache.kafka.common.serialization.StringSerializer");
		props.put("value.serializer", "org.apache.kafka.common.serialization.StringSerializer");
		props.put("retries", 0);
		props.put("acks", "all");
		props.put("batch.size", 20_000);
		props.put("buffer.memory", 400_000);

		KafkaProducer<String, String> producer = new KafkaProducer<String, String>(props);

		Map<String, String> datos = new HashMap<>();
		datos.put("Ana", "12");
		datos.put("Beatriz", "13");
		datos.put("Angel", "14");
		
		datos.forEach((key, value) -> {
			producer.send(new ProducerRecord<String, String>("deimos-cluster", key, value));
			System.out.println("Enviado a deimos-cluster: " + key + ", " + value);
		});
		
		// Enviamos datos a otro topic para probar el merge en el consumidor
		Map<String, String> datos2 = new HashMap<>();
		datos2.put("Benito", "15");
		datos2.put("Miguel", "16");
		datos2.put("Rosa", "17");

		datos2.forEach((key, value) -> {
			producer.send(new ProducerRecord<String, String>("deimos-cluster-2", key, value));
			System.out.println("Enviadoa deimos-cluster-2: " + key + ", " + value);
		});
		
		producer.close();

	}
}
