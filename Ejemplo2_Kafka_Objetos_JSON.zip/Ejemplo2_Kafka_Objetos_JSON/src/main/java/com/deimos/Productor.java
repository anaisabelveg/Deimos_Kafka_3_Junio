package com.deimos;

import java.util.Properties;
import java.util.concurrent.ExecutionException;

import org.apache.kafka.clients.producer.Callback;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.clients.producer.RecordMetadata;

import com.deimos.models.Producto;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class Productor {

	public static void main(String[] args) throws JsonProcessingException {

		Properties props = new Properties();

		// Especificar los host y puertos de todos los brokers del cluster
		// Asegurar que tenemos los 3 brokers levantados
		props.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, "localhost:9092,localhost:9093,localhost:9094");

		// Elegir como serializar la clave y el valor del mensaje
		props.put("key.serializer", "org.apache.kafka.common.serialization.StringSerializer");
		props.put("value.serializer", "org.apache.kafka.common.serialization.StringSerializer");

		// Numero de intentos en caso de fallo
		props.put("retries", 0);

		// acknowledges -> confirmacion de recibo del mensaje
		// acks = 0; El productor no recibe ninguna confirmarcion si el mensaje se ha
		// enviado correctamente o no.
		// acks = 1; El productor espera la confirmacion del mensaje del broker que lo
		// ha recibido.
		// acks = all; El productor recibe la confirmacion cuando todas las replicas
		// sincronizadas del cluster lo han recibido.
		// Esta la opcion mas segura, pero mayor impacto en la latencia (rapidez).
		props.put("acks", "all");

		// Tamaño del buffer
		// Acumula los mensajes o eventos que pertenecen a la misma particion para
		// enviarlos
		props.put("batch.size", 20_000);

		// Controlar el total de memoria disponeble al productor
		props.put("buffer.memory", 400_000);

		// Crear el productor con las propiedades establecidas
		KafkaProducer<String, String> prod = new KafkaProducer<>(props);

		Producto producto = new Producto(1, "Pantalla", 129.95);
		
		// Para enviar mensajes necesitamos: topic, particion, key, value
		String topic = "deimos-cluster";
		int particion = 0;
		String key = "producto-1";
		String value = new ObjectMapper().writeValueAsString(producto);

		// 1ª opcion de envio asincrono
		// prod.send(new ProducerRecord<String, String>(topic, particion, key, value));

		// 2ª opcion de envio sincrono
//		try {
//			prod.send(new ProducerRecord<String, String>(topic, particion, key, value)).get();
//		} catch (InterruptedException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		} catch (ExecutionException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}

		// 3ª opcion de envio asincrono con callback
		prod.send(new ProducerRecord<String, String>(topic, particion, key, value), new Callback() {

			@Override
			public void onCompletion(RecordMetadata metadata, Exception ex) {
				// Probar con una particion inexistente para que genere error
				if (ex != null) {
					System.out.println("Ha habido un error");
					ex.printStackTrace();
				} else {
					System.out.println("Mensaje enviado con exito");
				}
			}
		});

		// Cerrar el productor
		prod.close();
	}

}
