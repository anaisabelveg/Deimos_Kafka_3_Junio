package com.deimos.kafka;

import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

import com.deimos.models.Producto;

@Service
public class Consumidor {
	
	@KafkaListener(topics = "deimos-cluster", groupId = "grupo1")
	public void recibirMensaje(Producto producto) {
		System.out.println("Mensaje recibido: " + producto);
	}
}
