package com.deimos;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.kafka.annotation.EnableKafka;

import com.deimos.kafka.Productor;
import com.deimos.models.Producto;

@SpringBootApplication
@EnableKafka()
public class Ejemplo4KafkaObjetosSpringBootApplication implements CommandLineRunner {
	
	@Autowired
	private Productor productor;

	public static void main(String[] args) {
		SpringApplication.run(Ejemplo4KafkaObjetosSpringBootApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		Producto producto = new Producto("Pantalla", 125.5);
		productor.enviarMensaje(producto);
	}

}
