package com.deimos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ejemplo3KafkaSpringBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
