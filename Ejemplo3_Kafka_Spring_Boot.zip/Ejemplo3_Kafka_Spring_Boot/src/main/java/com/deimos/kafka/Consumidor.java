package com.deimos.kafka;

import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

@Service
public class Consumidor {
	
	@KafkaListener(topics = "deimos-cluster")
	public void recibirMensaje(String mensaje) {
		System.out.println("Mensaje recibido: " + mensaje);
	}

}
