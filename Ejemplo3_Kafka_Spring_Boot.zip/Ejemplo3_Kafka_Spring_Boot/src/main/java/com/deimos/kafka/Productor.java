package com.deimos.kafka;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

/*
 * Principales anotaciones de Spring
 * 		@Repository  ->  se utiliza para crear repositorios, p.e. DAO
 * 		@Service  ->  se utiliza para servicios o business
 * 		@Component  -> un simple objeto
 * 		@Controller  -> en aplicaciones web sutiyen a los servlet
 * */

@Service
public class Productor {
	
	// Oye Spring, pasame el bean de tipo KafkaTemplate
	@Autowired
	private KafkaTemplate<String, String> kafkaTemplate;
	
	
	public void enviarMensaje(String mensaje) {
		kafkaTemplate.send("deimos-cluster", mensaje);
	}

}
