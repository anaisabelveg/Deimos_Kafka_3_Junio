package com.deimos.rest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.deimos.kafka.Productor;

@RestController
public class MensajesREST {
	
	@Autowired
	private Productor productor;  // DI
	
	// http://localhost:8080/kafka/hola
	@GetMapping("/kafka/{msg}")
	public void envios(@PathVariable(name = "msg")  String mensaje) {
		productor.enviarMensaje(mensaje);
	}

}
