package com.deimos.clients;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.deimos.models.Pedido;

@FeignClient(url = "localhost:8002", name="servicio-pedidos")
public interface PedidosClienteRest {
	
	@GetMapping("/crear/{id}/cantidad/{cantidad}")
	public Pedido crearPedido(@PathVariable int id, @PathVariable int cantidad);

}
