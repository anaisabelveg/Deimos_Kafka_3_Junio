package com.deimos.services;

import com.deimos.models.Carrito;
import com.deimos.models.Usuario;

public interface ICarritoService {
	
	Carrito crear(Usuario usuario);
	
	Usuario buscar(String user);
	
	Carrito agregarPedido(int id, int cantidad, String user);
	
	

}
