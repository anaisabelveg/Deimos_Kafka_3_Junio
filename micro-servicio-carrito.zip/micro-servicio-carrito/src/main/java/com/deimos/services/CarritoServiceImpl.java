package com.deimos.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.deimos.clients.PedidosClienteRest;
import com.deimos.clients.UsuariosClienteRest;
import com.deimos.models.Carrito;
import com.deimos.models.Pedido;
import com.deimos.models.Usuario;
import com.deimos.persistence.CarritosDAO;

@Service
public class CarritoServiceImpl implements ICarritoService{
	
	@Autowired
	private CarritosDAO dao;
	
	@Autowired
	private PedidosClienteRest pedidosFeign;
	
	@Autowired
	private UsuariosClienteRest usuariosFeign;

	@Override
	public Carrito crear(Usuario usuario) {
		// Comprobar si el usuario esta dado de alta
		if (buscar(usuario.getUser()) != null    ) {
			Carrito carrito = new Carrito();
			carrito.setUsuario(usuario);
			return dao.save(carrito);
		} else {
			Carrito carrito = new Carrito();
			Usuario usuarioCreado = usuariosFeign.crear(usuario);
			carrito.setUsuario(usuarioCreado);
			return dao.save(carrito);
		}
	}

	@Override
	public Usuario buscar(String user) {
		return usuariosFeign.buscar(user);
	}

	@Override
	public Carrito agregarPedido(int id, int cantidad, String user) {
		Pedido pedido = pedidosFeign.crearPedido(id, cantidad);
		Carrito carrito = dao.findByUsuarioUser(user);
		carrito.getContenido().add(pedido);
		double importe = carrito.getImporte() + (pedido.getProducto().getPrecio() * cantidad);
		carrito.setImporte(importe);
		return dao.save(carrito);
	}

}











