package com.deimos.rest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.deimos.models.Carrito;
import com.deimos.models.Usuario;
import com.deimos.services.ICarritoService;

@RestController
public class CarritoREST {
	
	@Autowired
	private ICarritoService carritoService;
	
	// http://localhost:8003/crear_carrito
	@PostMapping("/crear_carrito")
	public Carrito crear(@RequestBody Usuario usuario) {
		return carritoService.crear(usuario);
	}
	
	// http://localhost:8003/agregar/id/3/cantidad/100/user/Pepito
	@PutMapping("/agregar/id/{id}/cantidad/{cantidad}/user/{user}")
	public Carrito agregarPedido(@PathVariable int id, @PathVariable int cantidad,
			@PathVariable String user) {
		return carritoService.agregarPedido(id, cantidad, user);
	}

}
