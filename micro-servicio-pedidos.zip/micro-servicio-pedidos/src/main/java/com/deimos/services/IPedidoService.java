package com.deimos.services;

import com.deimos.models.Pedido;

public interface IPedidoService {
	
	Pedido crearPedido(int id, int cantidad);

}
