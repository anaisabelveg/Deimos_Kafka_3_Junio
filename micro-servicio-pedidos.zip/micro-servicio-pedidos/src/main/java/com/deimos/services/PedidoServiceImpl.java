package com.deimos.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.deimos.clients.ProductosClienteRest;
import com.deimos.models.Pedido;
import com.deimos.models.Producto;

@Service
public class PedidoServiceImpl implements IPedidoService{
	
	@Autowired
	private ProductosClienteRest clienteFeign;

	@Override
	public Pedido crearPedido(int id, int cantidad) {
		Producto producto = clienteFeign.buscar(id);
		return new Pedido(producto, cantidad);
	}

}
