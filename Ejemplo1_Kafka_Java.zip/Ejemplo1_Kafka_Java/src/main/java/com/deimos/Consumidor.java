package com.deimos;

import java.time.Duration;
import java.util.Collections;
import java.util.Properties;

import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;

public class Consumidor {

	public static void main(String[] args) {
		Properties props = new Properties();
		
		// Especificar los host y puertos de todos los brokers del cluster
		// Asegurar que tenemos los 3 brokers levantados
		props.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, "localhost:9092,localhost:9093,localhost:9094");
		
		// Elegir como deserializar la clave y el valor del mensaje
		props.put("key.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");
		props.put("value.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");
		
		// Asignar el consumidor a un grupo
		props.put("group.id", "grupo1");
		
		// Timeout por defecto de 3 segundos
		props.put("session.timeout.ms", 10_000);  // milisegundos
		
		// La cantidad minimo de bytes que quiere recibir del broker
		props.put("fetch.min.bytes", "1");
		
		// Cuanto tiempo como maximo esta dispuesto a esperar para recibir esa cantidad de bytes
		props.put("fetch.max.wait.ms", "1000");  // milisegundos
		
		// Crear el consumidor con esas propiedades
		KafkaConsumer<String, String> consumer = new KafkaConsumer<>(props);
		
		consumer.subscribe(Collections.singletonList("deimos-cluster"));
		
		try {
			while(true) {
				// El consumidor recibe los mensajes y le indico el tiempo que esperara
				// si no le han entregado mas mensajes del broker 
				ConsumerRecords<String, String> mensajes = consumer.poll(Duration.ofSeconds(10));
				
				for (ConsumerRecord<String, String> msg : mensajes) {
					System.out.println("Topic: " + msg.topic());
					System.out.println("Particion: " + msg.partition());
					System.out.println("Key: " + msg.key());
					System.out.println("Value: " + msg.value());
					System.out.println("---------------------");
				}
			}
		} catch(Exception ex) {
			ex.printStackTrace();
		} finally {
			consumer.close();
		}
		

	}

}
